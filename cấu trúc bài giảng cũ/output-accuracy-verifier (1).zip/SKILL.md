---
name: output-accuracy-verifier
description: Kiem tra do chuan xac khoa hoc ky thuat, kiem dinh thuat ngu song ngu tien tram, kiem tra link Drive hinh anh va doi chieu So tay Kieng ky truoc khi xuat phan hoi.
---
# Output Accuracy Verifier

Kỹ năng kiểm định chất lượng và độ chuẩn xác khoa học kỹ thuật của đầu ra, đóng vai trò như một Cổng Gác Độc Lập (Gatekeeper Plugin) trước khi gửi phản hồi cho người dùng.

*Nguyên tắc kiến trúc:* Kỹ năng được thiết kế hoạt động độc lập như một plugin tự chủ, có thể tùy biến, chỉnh sửa hoặc tháo gỡ mà không làm gián đoạn hay ảnh hưởng tới các kỹ năng khác.

## Chốt Chặn Tiền Trạm Bắt Buộc (Pre-flight Hard Stop)
Trước khi kiểm định nội dung phản hồi, kiểm tra tính khả dụng và toàn vẹn của nguồn dữ liệu:
- **Dừng ngay lập tức:** Nếu không tìm thấy tài liệu trong NotebookLM, gặp lỗi truy cập tài liệu, hoặc tài liệu tải lên Google Drive bị hỏng / quét OCR bị lỗi $\to$ **Lập tức dừng toàn bộ quy trình và hoạt động**, báo cáo sự cố rõ ràng và yêu cầu người dùng xác nhận. Tuyệt đối không để phản hồi tiếp tục dựa trên dữ liệu suy đoán hay phỏng đoán thay thế.

## Quy Trình Kiểm Chứng 4 Nhánh & Cổng Gác Phân Luồng Kép

1. **Kiểm chứng lý thuyết và thông số kỹ thuật qua tài liệu gốc:** 
   - Đối chiếu số liệu, công thức, đồ thị từ các tệp PDF/sách trong thư mục Google Drive và NotebookLM.
   - Cấm suy diễn thông số từ trí nhớ tham số chung chung.

2. **Kiểm định chuẩn hóa thuật ngữ song ngữ & Chốt chặn tiền trạm (Terminology Gatekeeper):**
   - Đối chiếu hệ thống thuật ngữ với sổ tay `Academic Bilingual Terminology Matrix` trên NotebookLM.
   - *Quy chuẩn hiển thị:* Thuật ngữ đã có trong sổ tay bắt buộc dùng dạng `Thuật ngữ tiếng Việt chuẩn (English Term)`.
   - *Chốt chặn kiểm định tính chủ động:* Nếu phát hiện bài giảng xuất hiện các thuật ngữ cốt lõi trong tài liệu học tập của Dũng bị gắn nhãn bị động `[Thuật ngữ mới]` mà chưa được quét tiền trạm qua 10 nguồn và đối chiếu chéo $\to$ **Từ chối phê duyệt đầu ra**.
   - *Chốt chặn chống dịch bừa:* Nếu thuật ngữ ngoài giáo trình phát sinh đột xuất chưa có trong sổ tay, bắt buộc giữ nguyên tiếng Anh: `English Term [Thuật ngữ mới]`.

3. **Kiểm chứng trực quan hóa & Giao thức Cổng gác Phân luồng kép (Dual-Pipeline Visual Gatekeeper):**
   - **Nhánh 1 – Trong bài giảng giáo trình tuần tự:**
     * *Chốt 1 (Ảnh gốc 1-1):* Bắt buộc có link Google Drive trực tiếp (`webViewLink`) chuẩn 1-1 cho `Figure X.Y` giáo trình (hoặc ghi rõ: *\"Không có hình ảnh trong mục này từ tài liệu...\"*). Nếu thiếu $\to$ **Từ chối phê duyệt**.
     * *Chốt 2 (Mô hình SVG liên hệ thực tế):* Nếu có khối `<svg>` minh họa trực quan:
       - Kiểm tra có thẻ nền vật lý `<rect fill="#0b1329"/>` chống trắng bảng.
       - Kiểm tra an toàn ký tự (không dùng ký tự thô gây lỗi `btoa`).
       - Kiểm tra có dòng thông số bóc tách (Detached Metadata Card).
       - **Quy tắc miễn trừ (Bypass Rule):** Cổng gác tuyệt đối KHÔNG đòi hỏi link Drive cho khối SVG này (bảo vệ Zero-Drive-Footprint).
     * *Chốt chặn phần cứng (Hardware Zero-Draw Rule):* Nếu phân mục về công nghệ chế tạo (LPE, MOCVD, MBE, SEM) mà AI cố tình sinh mã SVG vẽ lại thiết bị thay vì bóc tách ảnh giáo trình 1-1 $\to$ **Từ chối phê duyệt**.
   - **Nhánh 2 – Trong chế độ mô phỏng độc lập theo yêu cầu người dùng:**
     * Vô hiệu hóa kiểm tra link Drive.
     * Chỉ kiểm tra tính hợp lệ của mã SVG (thẻ mở/đóng, `viewBox`, thẻ nền vật lý, thẻ thông số bóc tách).

4. **Kiểm chứng tính toán bằng Python & Chống tái phạm:**
   - Chạy script kiểm tra độc lập các phép tính số học, tích phân, nghiệm giải tích trong phiên làm việc trước khi xuất ra.
   - Đối chiếu Khối 3 (Sổ tay Kiêng kỵ & Chống Tái phạm) trên NotebookLM, triệt tiêu văn mẫu, giải thích vòng vo và bảng số liệu dạng lưới nhiều cột gây mỏi mắt.

## Kiểm Chuẩn Bắt Buộc Về Tag Phân Định Nguồn (Strict Source Boundary Audit)
- Bất kỳ dữ liệu nào không nằm trong tài liệu gốc trên NotebookLM đều BẮT BUỘC phải gắn tag rõ ràng: `[Nguồn: ...]`, `[Mở rộng]`, `[Nghi vấn]`, `[Cảnh báo biên]`, `[Giả thuyết chủ đích]`.
