---
name: physics-diagram-studio
description: Chuyên bóc tách, quản lý và tạo lập giản đồ, sơ đồ và đồ thị kỹ thuật trong vật lý bán dẫn và quang tử. Quản lý ảnh gốc 1-1 từ giáo trình trên Google Drive, sinh mã Vector SVG phẳng phân tầng cho Canvas Cockpit, tách rời thẻ thông số và mô phỏng giải tích số qua Python.
---
# Physics Diagram Studio

Kỹ năng chuyên sâu phục vụ trực quan hóa học thuật và quản lý tài nguyên hình ảnh kỹ thuật (giản đồ dải năng lượng, cấu trúc linh kiện bán dẫn, đường đặc tuyến quang học, phân bố trường và mode dẫn sóng).

## When to Use

Kích hoạt kỹ năng này trong các trường hợp sau:
  - Khi người dùng cung cấp tài liệu gốc (PDF giáo trình, slide bài giảng, ảnh chụp) trên Google Drive và cần bóc tách hình ảnh, giản đồ để phục vụ bài giảng.
  - Khi cần hiển thị hình ảnh minh họa đồng bộ với tiến trình giải thích lý thuyết.
  - Khi cần tạo lập mô hình vector SVG phẳng phân tầng (Layered Flat SVG) cho Canvas của Cockpit Extension.
  - Khi cần bóc tách, giải thích chi tiết các trục tọa độ, thông số, điểm uốn và số liệu thực nghiệm trên một hình vẽ kỹ thuật.
  - Khi cần tự động vẽ đồ thị mô phỏng vật lý hoặc giải tích số qua Python.

## 1. Ma Trận Phân Loại Nội Dung Thị Giác (Visual Content Taxonomy)

Để đảm bảo tính trung thực khoa học và tránh mô hình hóa giả mạo (pseudo-engineering), hệ thống tuân thủ nghiêm ngặt 2 nhóm phân loại:

1. **Nhóm A – Thực thể Phần cứng & Thực nghiệm (Hardware & Micrographs):**
   - *Bao gồm:* Sơ đồ hệ thống thiết bị chế tạo (buồng mọc màng LPE, buồng phản ứng MOCVD, hệ thống siêu chân không MBE), ảnh hiển vi điện tử (SEM, TEM, AFM), sơ đồ đóng gói vỏ chip (packaging/mount), mạch đo và đồ thị thực nghiệm gốc của tác giả.
   - *Quy chuẩn thực thi:* **100% BẮT BUỘC dùng ảnh trích xuất nguyên bản 1-1 từ Google Drive** (Single Perfect Composite Link đã xoay $0^\circ$, đủ Bộ 3 Định danh).
   - *Chốt chặn phần cứng thực tế (Hardware Zero-Draw Rule):* Đối với máy móc, thiết bị, buồng công nghệ được nhắc trong giáo trình nhưng sách **KHÔNG CÓ** hình ảnh trực quan $\to$ **TUYỆT ĐỐI KHÔNG TỰ VẼ SVG, TRỪ KHI NGƯỜI DÙNG CÓ YÊU CẦU ĐÍCH DANH**.

2. **Nhóm B – Mô hình Cơ chế & Cấu trúc Lượng tử Vi mô (Quantum Mechanisms & Band Models):**
   - *Bao gồm:* Giản đồ dải năng lượng ($E-z, E-k$), cấu trúc giếng lượng tử (QW, DQW, MQW, SCH), phân bố chiết suất, mode quang học dẫn sóng, hàm sóng electron/lỗ trống, chuyển dời hạt dẫn.
   - *Quy chuẩn thực thi:* Trong bài giảng sách, ảnh gốc 1-1 vẫn đặt ở đầu Tầng 2 để làm mỏ neo; phần giải thích liên hệ trực quan bên dưới (hoặc khi sách không có hình) **ưu tiên xuất mã Layered Flat SVG** sang Canvas của Cockpit.

## 2. Quy Chuẩn Thiết Kế: Layered Flat SVG + Detached Metadata Card

Áp dụng triệt để nguyên tắc: **"Hình tinh gọn biến số – Thẻ ôm trọn số liệu"**:

1. **Nửa 1: Layered Flat SVG (Không gian Trực giác & Hình học):**
   - Hình vẽ chỉ tập trung vào các đường biên thế năng, dải năng lượng ($E_c, E_v$), mức lượng tử ($e_1, e_2$) và hàm sóng ($\psi_1, \psi_2$).
   - Nhãn text trên hình: **DUY NHẤT ký hiệu biến cốt lõi**, tuyệt đối không nhồi nhét số đo dày đặc làm che khuất các đường cong khi phóng to $200\% - 400\%$ trên Canvas.
   - **Thẻ nền vật lý chống rỗng:** Luôn có `<rect width="100%" height="100%" fill="#0b1329" rx="10"/>` ngay sau thẻ mở `<svg>` để triệt tiêu lỗi mất nền / bảng trắng khi Extension nạp qua thẻ `<img>` hoặc Canvas.
   - **Khung nhìn chuẩn hóa (Responsive viewBox):**
     * *Dạng ngang (Landscape 16:9):* `viewBox="0 0 850 500"` (cho giản đồ $E-z$, $E-k$, phân bố trường ngang).
     * *Dạng đứng (Portrait 3:4 hoặc 2:3):* `viewBox="0 0 500 700"` (cho cấu trúc lớp màng mỏng epitaxy, mặt cắt dọc VCSEL/RWG).
   - **An toàn mã hóa (Crash-proof Encoding):** Chuẩn hóa toàn bộ ký tự hiển thị (dùng mã thực thể XML hoặc ký tự an toàn) để ngăn chặn việc gây sập hàm `window.btoa()` của Extension.
   - **Tối ưu độ dài (Clean & Compact SVG):** Tận dụng `<path>` gộp tọa độ, giữ độ dài khối SVG trong khoảng 30–50 dòng hiệu dụng để không làm tràn cuộn khung chat.
   - **Tự chứa Metadata (Self-contained Metadata):** Khuyến khích nhúng thẻ `<desc>` chứa chuỗi JSON thông số ngay trong thẻ `<svg>` để Extension bóc tách trực tiếp:
     `<desc>{"Lz": "8.0 nm", "Delta_Ec": "0.28 eV", "Delta_e12": "36 meV"}</desc>`.
   - Luôn bọc trong khối code Markdown chuẩn: ````xml ```` hoặc ````svg ````.

2. **Nửa 2: Detached Metadata Card (Không gian Thông số & Đo đạc):**
   - Đặt ngay dưới khối SVG. Tuyệt đối không dùng bảng số liệu dạng lưới nhiều cột khô khan (chống mỏi mắt).
   - Sử dụng định dạng dòng ngắn gọn (Inline Badges / Thẻ Cockpit Parameter Card):
     `↳ [Trục X]: Tọa độ không gian z (nm) | [Trục Y]: Năng lượng E (eV) | [Rào thế]: Delta_Ec = 0.28 eV, Delta_e12 = 36 meV`
   - Kết hợp Thẻ đo trạng thái màu sắc Phương án C (`[■■■■■■■■□□]`) khi cần đánh giá độ sâu rào thế hoặc phân bổ dòng.

## 3. Nguyên Tắc Cốt Lõi Về Dữ Liệu Hình Ảnh Giáo Trình

1. **Tuyệt đối bảo toàn dữ liệu gốc (Zero Data Alteration):** Không can thiệp thuật toán vẽ đè, chỉnh sửa hay làm biến dạng bất kỳ đường cong, trục tọa độ, con số hay ký hiệu nào của tác giả. Ảnh trích xuất phải phản ánh nguyên bản 100% tài liệu gốc.
2. **Quy chuẩn gửi link giảng dạy (Single Perfect Composite Link):**
   - Khi gửi link hình ảnh kèm theo tiến trình bài giảng, **CHỈ GỬI DUY NHẤT 1 LINK của hình ảnh đã được ghép và xoay hoàn hảo (Perfect Stitched & Rotated Composite)**.
   - Mọi hình vẽ đa trang hoặc in xoay ngang đều phải được chuẩn hóa góc đọc $0^\circ$ và ghép nối liền mạch thành một file ảnh toàn cảnh chất lượng cao ($\ge 300\,\text{DPI}$) kèm caption đầy đủ ở chân hình.
3. **Quy chuẩn nhúng link Drive 1-1 vào Hồ sơ Kiểm toán Docs:**
   - Trong tệp Google Docs kiểm toán sống (`Ho_so_Kiem_toan_Lo_trinh_Chuong_X`), Bảng kiểm toán hình ảnh bắt buộc phải chèn link Google Drive trực tiếp (`webViewLink`) chuẩn 1-1 cho toàn bộ 100% các Figure giáo trình.
4. **Bảo vệ tài nguyên Drive (Zero-Drive-Footprint):**
   - Các hình vẽ SVG tự tạo phục vụ hiển thị Canvas nội bộ 100% trên chat; tuyệt đối không tự ý upload file ảnh rác lên Google Drive trừ khi người dùng yêu cầu đích danh.

## 4. Giao Thức Nhận Diện Hình Đa Trang (Multi-Page Figure Detection)
... (Giữ nguyên giao thức quét đa trang có nhãn và không nhãn)
